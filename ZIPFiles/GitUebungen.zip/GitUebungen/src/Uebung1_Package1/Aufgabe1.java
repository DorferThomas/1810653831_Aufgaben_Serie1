package Uebung1_Package1;

public class Aufgabe1 {
    public static void main(String[] args){
        System.out.println("FH Kufstein Tirol");
    }
}
